from flask import Flask, render_template, request
import joblib

# Initialize Flask app
app = Flask(__name__)

# Load model and TF-IDF vectorizer
model = joblib.load('models/fake_job_post_rf.pkl')
tfidf = joblib.load('models/tfidf_vectorizer.pkl')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        job_text = request.form['jobtext']

        # Transform text
        input_features = tfidf.transform([job_text])

        # Predict
        prediction = model.predict(input_features)[0]

        # Output message
        if prediction == 0:
            result = "✅ This looks like a REAL job posting!"
        else:
            result = "🚨 Warning: This looks like a FAKE job posting!"

        return render_template('home.html', prediction_text=result)

if __name__ == '__main__':
    app.run(debug=True)
